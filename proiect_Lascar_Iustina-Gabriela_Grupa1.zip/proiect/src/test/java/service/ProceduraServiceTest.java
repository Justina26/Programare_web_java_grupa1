package service;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import proiect.domain.*;
import proiect.repository.*;
import proiect.service.ComandaService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProceduraServiceTest {

    @InjectMocks
    private ComandaService comandaService;


    @Mock
    private ComandaRepo comandaRepo;


    private static Optional<Comanda>comanda1;

    @BeforeAll
    public static void setup(){
        Comanda comandaNoua = new Comanda();
        comandaNoua.setId(2l);
        comandaNoua.setDescriere("test");

        comanda1=Optional.of(comandaNoua);

    }

    @Test
    public void TestDataPlasariiLessThanCurrentDate(){
        when(comandaRepo.findById(2l)).thenReturn(comanda1);
        Optional<Comanda> comandaTest= comandaRepo.findById(2l);
        assertTrue(comandaTest.get().getDescriere().equals("test"));
    }

}
