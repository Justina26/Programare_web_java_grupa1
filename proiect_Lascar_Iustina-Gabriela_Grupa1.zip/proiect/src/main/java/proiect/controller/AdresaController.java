package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import proiect.service.AdresaService;

@RestController
@RequestMapping("/adresa.html")
public class AdresaController {

    @Autowired
    private AdresaService adresaService;



}
