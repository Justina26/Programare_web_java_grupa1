package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.AngajatService;

@RestController
@RequestMapping("/angajat")
public class AngajatController {

    @Autowired
    private AngajatService angajatService;



}
