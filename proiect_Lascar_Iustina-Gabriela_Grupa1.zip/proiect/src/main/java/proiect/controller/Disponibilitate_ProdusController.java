package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.Disponibilitate_ProdusService;

@RestController
@RequestMapping("/disponibilitate_produs")
public class Disponibilitate_ProdusController {

    @Autowired
    private Disponibilitate_ProdusService disponibilitate_produsService;



}
