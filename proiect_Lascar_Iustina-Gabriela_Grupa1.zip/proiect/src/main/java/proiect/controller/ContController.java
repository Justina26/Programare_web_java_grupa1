package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.ContService;

@RestController
@RequestMapping("/cont")
public class ContController {

    @Autowired
    private ContService contService;



}
