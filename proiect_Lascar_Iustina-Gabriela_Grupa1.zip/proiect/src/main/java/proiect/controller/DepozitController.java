package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.DepozitService;

@RestController
@RequestMapping("/depozit")
public class DepozitController {

    @Autowired
    private DepozitService depozitService;



}
