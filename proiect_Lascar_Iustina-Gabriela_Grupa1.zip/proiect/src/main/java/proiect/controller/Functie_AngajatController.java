package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.domain.Functie_Angajat;
import proiect.service.Functie_AngajatService;

@RestController
@RequestMapping("/functie_angajat")
public class Functie_AngajatController {

    @Autowired
    private Functie_AngajatService fucntie_angajatService;



}
