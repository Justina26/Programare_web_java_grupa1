package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.domain.Functie;
import proiect.service.FunctieService;

@RestController
@RequestMapping("/functie")
public class FunctieController {

    @Autowired
    private FunctieService coletService;



}
