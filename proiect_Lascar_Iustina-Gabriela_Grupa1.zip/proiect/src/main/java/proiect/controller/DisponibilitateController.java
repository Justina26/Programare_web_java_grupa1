package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.DisponibilitateService;

@RestController
@RequestMapping("/disponibilitate")
public class DisponibilitateController {

    @Autowired
    private DisponibilitateService disponibilitateService;



}
