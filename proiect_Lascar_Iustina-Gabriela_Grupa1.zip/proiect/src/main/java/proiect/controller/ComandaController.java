package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import proiect.domain.Colet;
import proiect.domain.Comanda;
import proiect.service.ClientException;
import proiect.service.ColetService;
import proiect.service.ComandaService;

import java.net.URI;
import java.util.Collection;

@RestController
@RequestMapping("/comanda")
public class ComandaController {

    @Autowired
    private ComandaService comandaService;

    @Autowired
    private ColetService coletService;

    @GetMapping
    public ResponseEntity<Iterable<Comanda>> getComenzi(){
        Collection<Comanda> comenzi=(Collection<Comanda>) comandaService.getAllComenzi();
        if(comenzi.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(comenzi);
    }

    @PostMapping(path = "/colet",consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<Void>addColet(String descriere){
        try {
            Colet colet=comandaService.addColet(descriere);
            URI uri= WebMvcLinkBuilder.linkTo(ComandaController.class).slash("colet").slash(colet.getId()).toUri();
            return ResponseEntity.created(uri).build();
        }catch (ClientException | DataIntegrityViolationException clientException){
            return ResponseEntity.badRequest().build();
        }
    }

}
