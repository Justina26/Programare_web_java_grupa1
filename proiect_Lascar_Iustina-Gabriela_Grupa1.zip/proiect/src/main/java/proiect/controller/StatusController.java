package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.StatusService;

@RestController
@RequestMapping("/depozit")
public class StatusController {

    @Autowired
    private StatusService statusService;



}
