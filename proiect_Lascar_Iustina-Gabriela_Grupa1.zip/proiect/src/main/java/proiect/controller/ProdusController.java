package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.ProdusService;

@RestController
@RequestMapping("/produs")
public class ProdusController {

    @Autowired
    private ProdusService produsService;



}
