package proiect.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import proiect.service.ColetService;

@RestController
@RequestMapping("/colet")
public class ColetController {

    @Autowired
    private ColetService coletService;



}
