package proiect.controller;


import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.*;
import proiect.domain.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import proiect.domain.Cont;
import proiect.service.ClientException;
import proiect.service.ClientService;

import java.net.URI;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

@RestController
@RequestMapping("/client")
public class ClientController {

    @Autowired
    private ClientService clientService;

    @GetMapping
    public ResponseEntity<Iterable<Client>> getClients(){
        Collection<Client> clients=(Collection<Client>) clientService.findAllClients();
        if(clients.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(clients);
    }




}
