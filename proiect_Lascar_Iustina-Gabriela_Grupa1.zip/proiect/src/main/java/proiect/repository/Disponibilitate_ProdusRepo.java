package proiect.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import proiect.domain.Disponibilitate;
import proiect.domain.Disponibilitate_Produs;


@Repository
public interface Disponibilitate_ProdusRepo extends CrudRepository<Disponibilitate_Produs, Integer> {

}
