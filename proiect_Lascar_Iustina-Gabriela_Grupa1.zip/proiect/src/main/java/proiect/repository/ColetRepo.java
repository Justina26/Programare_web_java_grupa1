package proiect.repository;

import proiect.domain.Colet;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ColetRepo extends CrudRepository<Colet,Integer> {
}
