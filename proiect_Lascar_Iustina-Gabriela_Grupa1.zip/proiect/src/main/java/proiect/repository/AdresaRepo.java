package proiect.repository;

import proiect.domain.Adresa;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface AdresaRepo extends CrudRepository<Adresa, Integer> {
    Optional<Adresa> findByLocalitate(String localitate);
}
