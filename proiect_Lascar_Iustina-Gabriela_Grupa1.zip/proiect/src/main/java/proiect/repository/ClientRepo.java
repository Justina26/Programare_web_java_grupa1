package proiect.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import proiect.domain.Client;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface ClientRepo extends JpaRepository<Client, Long> {
    Optional<Client> findByEmail(String email);

    List<Client> findByNume(String nume);

    List<Client> findByPrenume(String prenume);

    List<Client> findByNumeAndPrenume(String nume, String prenume);

}
