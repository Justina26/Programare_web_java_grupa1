package proiect.repository;

import proiect.domain.Angajat;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AngajatRepo extends CrudRepository<Angajat,Integer> {
}
