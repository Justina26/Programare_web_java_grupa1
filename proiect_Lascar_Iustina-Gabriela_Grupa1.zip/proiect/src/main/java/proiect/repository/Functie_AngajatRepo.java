package proiect.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import proiect.domain.Adresa;
import proiect.domain.Functie_Angajat;

import java.util.Optional;


@Repository
public interface Functie_AngajatRepo extends CrudRepository<Functie_Angajat, Integer> {

}
