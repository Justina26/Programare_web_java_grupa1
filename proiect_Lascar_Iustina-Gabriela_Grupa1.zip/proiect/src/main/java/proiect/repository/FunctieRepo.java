package proiect.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import proiect.domain.Adresa;
import proiect.domain.Functie;

import java.util.Optional;


@Repository
public interface FunctieRepo extends CrudRepository<Functie, Integer> {

}
