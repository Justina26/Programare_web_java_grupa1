package proiect.repository;

import proiect.domain.Depozit;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepozitRepo extends CrudRepository<Depozit,Integer> {

}
