package proiect.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import proiect.domain.Adresa;
import proiect.domain.Client;
import proiect.domain.Produs;

import java.util.List;
import java.util.Optional;


@Repository
public interface ProdusRepo extends CrudRepository<Produs, Integer> {
    List<Produs> findByPret(Float pret);
}
