package proiect.repository;

import proiect.domain.Comanda;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ComandaRepo extends CrudRepository<Comanda,Long> {


}
