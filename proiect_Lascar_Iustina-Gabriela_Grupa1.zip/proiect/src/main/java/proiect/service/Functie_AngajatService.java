package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.AdresaRepo;
import proiect.repository.Functie_AngajatRepo;

@Service
public class Functie_AngajatService {

    @Autowired
    private Functie_AngajatRepo functie_angajatRepo;


}
