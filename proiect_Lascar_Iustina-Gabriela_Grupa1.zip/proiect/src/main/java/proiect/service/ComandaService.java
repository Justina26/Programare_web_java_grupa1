package proiect.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import proiect.domain.*;
import proiect.repository.*;

import java.sql.Date;
import java.util.Optional;

@Service
public class ComandaService {

    @Autowired
    private ClientRepo clientRepo;

    @Autowired
    private ComandaRepo comandaRepo;

    @Autowired
    private ColetRepo coletRepo;


    public Iterable<Comanda> getAllComenzi(){
        return comandaRepo.findAll();
    }

    public Colet addColet(String descriere) throws DataIntegrityViolationException {
        Optional<Client>client= clientRepo.findByEmail("email");
        if(!client.isPresent()){
            throw ClientException.clientNotFound();
        }
        return coletRepo.save(new Colet(descriere));

    }


}
