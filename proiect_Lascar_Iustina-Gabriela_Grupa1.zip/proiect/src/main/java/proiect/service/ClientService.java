package proiect.service;


import jdk.nashorn.internal.ir.SplitReturn;
import org.springframework.dao.DataIntegrityViolationException;
import proiect.domain.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.domain.Cont;
import proiect.repository.ClientRepo;
import proiect.repository.ContRepo;
import proiect.repository.ProdusRepo;

import java.sql.Driver;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ClientService {

    @Autowired
    private ClientRepo clientRepo;

    @Autowired
    public ContRepo contRepo;

    @Autowired
    public ProdusRepo produsRepo;

    public Iterable<Client> findAllClients(){
        return clientRepo.findAll();
    }

    public ClientService(ClientRepo clientRepo) {
        this.clientRepo = clientRepo;
    }

    public Client create(Client client) {
        checkUniqueEmail(client);
        return clientRepo.save(client);
    }

    public Client update(Client client) {
        Client existingClient = clientRepo.findById(client.getId())
                .orElseThrow(() -> new ClientNotFoundException());
        if(!client.getEmail().equals(existingClient.getEmail())) {
            checkUniqueEmail(client);
        }
        return  clientRepo.save(client);
    }

    public List<Client> get(String nume, String prenume) {
        if(nume != null) {
            if(prenume != null) {
                return clientRepo.findByNumeAndPrenume(nume,prenume);
            }
            return clientRepo.findByNume(nume);
        }
        if(prenume != null) {
            return clientRepo.findByPrenume(prenume);
        }
        return clientRepo.findAll();
    }


    private void checkUniqueEmail(Client client) {
        Optional<Client> existingDriver = clientRepo.findByEmail(client.getEmail());
        if (existingDriver.isPresent()) {
            throw new ClientAlreadyExistsException();
        }
    }


}
