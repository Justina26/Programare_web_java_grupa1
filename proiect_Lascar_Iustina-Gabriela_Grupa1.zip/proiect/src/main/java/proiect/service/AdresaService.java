package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.domain.Adresa;
import proiect.domain.Client;
import proiect.domain.Comanda;
import proiect.repository.AdresaRepo;
import proiect.repository.ClientRepo;
import proiect.repository.ComandaRepo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class AdresaService {

    @Autowired
    private AdresaRepo adresaRepo;

}
