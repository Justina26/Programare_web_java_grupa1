package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.AdresaRepo;
import proiect.repository.FunctieRepo;

@Service
public class FunctieService {

    @Autowired
    private FunctieRepo functieRepo;


}
