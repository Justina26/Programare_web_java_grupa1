package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.AdresaRepo;
import proiect.repository.DepozitRepo;

@Service
public class DepozitService {

    @Autowired
    private DepozitRepo depozitRepo;


}
