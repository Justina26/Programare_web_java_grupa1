package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.AdresaRepo;
import proiect.repository.StatusRepo;

@Service
public class StatusService {

    @Autowired
    private StatusRepo statusRepo;


}
