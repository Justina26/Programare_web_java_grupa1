package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.AdresaRepo;
import proiect.repository.ProdusRepo;

@Service
public class ProdusService {

    @Autowired
    private ProdusRepo produsRepo;

//    public Float SumaPreturi(Float pret1, Float pret2);

}
