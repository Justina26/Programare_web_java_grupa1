package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.ColetRepo;

@Service
public class ColetService {

    @Autowired
    private ColetRepo coletRepo;


}
