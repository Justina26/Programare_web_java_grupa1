package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.ContRepo;

@Service
public class ContService {

    @Autowired
    private ContRepo contRepo;


}
