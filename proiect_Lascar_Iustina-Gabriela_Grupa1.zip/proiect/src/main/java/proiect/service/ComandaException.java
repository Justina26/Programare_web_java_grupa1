package proiect.service;

public class ComandaException extends RuntimeException{
    public enum ErrorCodeComanda {
        COMANDA_NU_A_FOST_GASITA,
        COLETUL_NU_A_FOST_GASIT,
        ANGAJATUL_NU_A_FOST_GASIT,
        DEPOZITUL_NU_A_FOST_GASIT,
        ADRESA_NU_A_FOST_GASITA

    }

    private ErrorCodeComanda errorCodeComanda;

    public ComandaException(ErrorCodeComanda errorCodeComanda){
        this.errorCodeComanda =errorCodeComanda;
    }
    public static ComandaException coletNotFound(){ return new ComandaException(ErrorCodeComanda.COLETUL_NU_A_FOST_GASIT);}
    public static ComandaException angajatNotFound(){ return new ComandaException(ErrorCodeComanda.ANGAJATUL_NU_A_FOST_GASIT);}
    public static ComandaException depozitNotFound(){ return new ComandaException(ErrorCodeComanda.DEPOZITUL_NU_A_FOST_GASIT);}
    public static ComandaException adresaNotFound(){ return new ComandaException(ErrorCodeComanda.ADRESA_NU_A_FOST_GASITA);}

    public ErrorCodeComanda getErrorCodeComanda() {
        return errorCodeComanda;
    }

    public static ComandaException comandaNotFound(){
        return new ComandaException(ErrorCodeComanda.COMANDA_NU_A_FOST_GASITA);
    }
}
