package proiect.service;

public class ClientNotFoundException extends RuntimeException {

    public ClientNotFoundException() {
        super("The client doesn't exist.");
    }
}
