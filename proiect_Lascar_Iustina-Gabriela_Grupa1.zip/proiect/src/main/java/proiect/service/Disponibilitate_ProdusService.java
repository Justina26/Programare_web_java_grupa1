package proiect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import proiect.repository.DisponibilitateRepo;
import proiect.repository.Disponibilitate_ProdusRepo;

@Service
public class Disponibilitate_ProdusService {

    @Autowired
    private Disponibilitate_ProdusRepo disponibilitate_produsRepo;


}
