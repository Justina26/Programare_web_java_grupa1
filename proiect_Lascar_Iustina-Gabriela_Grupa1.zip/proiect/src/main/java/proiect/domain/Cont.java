package proiect.domain;

import org.springframework.lang.NonNull;

import javax.persistence.*;

@Entity
@Table(name = "cont")
public class Cont {

    @Id
    @Column
    private Long id_cont;

    @Column
    private String username;

    @Column
    private String parola;

    @Column
    private String rol;

    public Long getId_cont() {
        return id_cont;
    }

    public void setId_cont(Long id_cont) {
        this.id_cont = id_cont;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public Cont(String banca, int sumaDeBani, String numarCard) {
        this.username = username;
        this.parola = parola;
        this.rol = rol;
    }

    @OneToOne
    @JoinColumn(name = "id_client")
    private Client client;

    @OneToOne
    @JoinColumn(name = "id_comanda")
    private Comanda comanda;
}
