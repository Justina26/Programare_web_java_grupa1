package proiect.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Client")
public class Client {

    @Id
    @Column
    private Long id_client;

    @Column
    private String nume;

    @Column
    private String prenume;

    @Column
    private Date data_nasterii;

    @Column
    private String email;

    @Column
    private String telefon;

    public Long getId() {
        return id_client;
    }

    public void setId(Long id) { this.id_client = id_client; }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public Date getData_nasterii() {
        return data_nasterii;
    }

    public void setData_nasterii(Date data_nasterii) {
        this.data_nasterii = data_nasterii;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public Client(String nume, String prenume, Date data_nasterii, String email,  String telefon) {
        this.nume = nume;
        this.prenume = prenume;
        this.data_nasterii = data_nasterii;
        this.email = email;
        this.telefon = telefon;

    }

    @OneToOne
    @JoinColumn(name = "id_adresa")
    private Adresa adresa;

}
