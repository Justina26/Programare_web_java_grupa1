package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Adresa")
public class Adresa {

    @Id
    @Column
    private Long id_adresa;

    @Column
    private String tara;

    @Column
    private String judetul;

    @Column
    private String localitate;

    @Column
    private String strada;

    @Column
    private String cod_postal;

    @Column
    private String detalii;

    public Long getId() {
        return id_adresa;
    }

    public void setId(Long id) {
        this.id_adresa = id_adresa;
    }

    public String getTara() {
        return tara;
    }

    public void setTara(String tara) {
        this.tara = tara;
    }

    public String getLocalitate() {
        return localitate;
    }

    public void setLocalitate(String localitate) {
        this.localitate = localitate;
    }

    public String getJudetul() {
        return judetul;
    }

    public void setJudetul(String judetul) {
        this.judetul = judetul;
    }

    public String getStrada() {
        return strada;
    }

    public void setStrada(String strada) {
        this.strada = strada;
    }

    public String getCod_postal() {
        return cod_postal;
    }

    public void setCod_postal(String cod_postal) {
        this.cod_postal = cod_postal;
    }

    public String getDetalii() {
        return detalii;
    }

    public void setDetalii(String detalii) {
        this.detalii = detalii;
    }

    public Adresa(String tara, String localitate, String judetul, String strada, String cod_postal, String detalii) {
        this.tara = tara;
        this.localitate = localitate;
        this.judetul = judetul;
        this.strada = strada;
        this.cod_postal = cod_postal;
        this.detalii = detalii;
    }

}
