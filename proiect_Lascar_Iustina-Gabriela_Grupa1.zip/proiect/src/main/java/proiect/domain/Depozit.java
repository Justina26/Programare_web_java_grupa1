package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Depozit")
public class Depozit {

    @Id
    @Column
    private Long id_depozit;

    @Column
    private String denumire;

    public Long getId_depozit() {
        return id_depozit;
    }

    public void setId_depozit(Long id_depozit) {
        this.id_depozit = id_depozit;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public Adresa getAdresa() {
        return adresa;
    }

    public void setAdresa(Adresa adresa) {
        this.adresa = adresa;
    }

    public Depozit(String denumire, String locatie, int capacitate) {
        this.denumire = denumire;

    }

    @OneToOne
    @JoinColumn(name = "id_adresa")
    private Adresa adresa;
}
