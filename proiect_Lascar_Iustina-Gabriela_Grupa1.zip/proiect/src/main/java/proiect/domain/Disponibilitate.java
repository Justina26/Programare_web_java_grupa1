package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Disponibilitate")
public class Disponibilitate {

    @Id
    @Column
    private Long id_disponibilitate;

    @Column
    private String descriere;

    @Column
    private Boolean disponibil;

    public Disponibilitate(String descriere, Boolean disponibil) {
        this.descriere = descriere;
        this.disponibil = disponibil;

    }

    public Long getId_disponibilitate() {
        return id_disponibilitate;
    }

    public void setId_disponibilitate(Long id_disponibilitate) {
        this.id_disponibilitate = id_disponibilitate;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Boolean getDisponibil() {
        return disponibil;
    }

    public void setDisponibil(Boolean disponibil) {
        this.disponibil = disponibil;
    }
}
