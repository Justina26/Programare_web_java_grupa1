package proiect.domain;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "Angajat")
public class Angajat {

    @Id
    @Column
    private Long id_angajat;

    @Column
    private String nume;

    @Column
    private String prenume;

    @Column
    private Date data_nasterii;

    public Long getId() {
        return id_angajat;
    }

    public void setId(Long id) {
        this.id_angajat = id_angajat;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public Date getData_nasterii() {
        return data_nasterii;
    }

    public void setData_nasterii(Date data_nasterii) {
        this.data_nasterii = data_nasterii;
    }


    public Angajat(String nume, String prenume, Date data_nasterii) {
        this.nume = nume;
        this.prenume = prenume;
        this.data_nasterii = data_nasterii;

    }


    @ManyToOne
    @JoinColumn(name = "id_depozit")
    private Depozit depozit;

    @ManyToOne
    @JoinColumn(name = "id_functie_angajat")
    private Functie_Angajat functie_angajat;

}
