package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Status")
public class Status {

    @Id
    @Column
    private Long id_status;

    @Column
    private String denumire;

    @Column
    private String descriere;

    public Status(String denumire, String descriere) {
        this.denumire = denumire;
        this.descriere = descriere;

    }

    public Long getId_status() {
        return id_status;
    }

    public void setId_status(Long id_status) {
        this.id_status = id_status;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }
}
