package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Disponibilitate_Produs")
public class Disponibilitate_Produs {

    @Id
    @Column
    private Long id_disponibilitate_produs;

    @Column
    private Float cantitate_disponibila;

    public Disponibilitate_Produs(Float cantitate_disponibila) {
        this.cantitate_disponibila = cantitate_disponibila;
    }

    public Long getId_disponibilitate_produs() {
        return id_disponibilitate_produs;
    }

    public void setId_disponibilitate_produs(Long id_disponibilitate_produs) {
        this.id_disponibilitate_produs = id_disponibilitate_produs;
    }

    public Float getCantitate_disponibila() {
        return cantitate_disponibila;
    }

    public void setCantitate_disponibila(Float cantitate_disponibila) {
        this.cantitate_disponibila = cantitate_disponibila;
    }

    public Disponibilitate getDisponibilitate() {
        return disponibilitate;
    }

    public void setDisponibilitate(Disponibilitate disponibilitate) {
        this.disponibilitate = disponibilitate;
    }

    @OneToOne
    @JoinColumn(name = "id_disponibilitate")
    private Disponibilitate disponibilitate;
}
