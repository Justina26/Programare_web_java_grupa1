package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Functie")
public class Functie {

    @Id
    @Column
    private Long id_functie;

    @Column
    private String denumire;

    @Column
    private String descriere;

    @Column
    private Float salariu;

    public Functie(String denumire, String descriere, Float salariu) {
        this.denumire = denumire;
        this.descriere = descriere;
        this.salariu= salariu;
    }

    public Long getId_functie() {
        return id_functie;
    }

    public void setId_functie(Long id_functie) {
        this.id_functie = id_functie;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Float getSalariu() {
        return salariu;
    }

    public void setSalariu(Float salariu) {
        this.salariu = salariu;
    }
}
