package proiect.domain;


import javax.persistence.*;

@Entity
@Table(name = "Colet")
public class Colet {

    @Id
    @Column
    private Long id_colet;

    @Column
    private String descriere;

    public Long getId() {
        return id_colet;
    }

    public void setId(Long id) {
        this.id_colet = id_colet;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Colet(String descriere) {
        this.descriere = descriere;
    }

    @ManyToOne
    @JoinColumn(name = "id_produs")
    private Produs produs;
}
