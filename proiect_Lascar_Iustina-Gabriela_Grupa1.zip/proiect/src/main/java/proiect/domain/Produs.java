package proiect.domain;

import javax.persistence.*;

@Entity
@Table(name = "Produs")
public class Produs {

    @Id
    @Column
    private Long id_produs;

    @Column
    private Float cantitate_cerere;

    @Column
    private String denumire;

    @Column
    private Float pret;

    public Produs(Float cantitate_cerere, String denumire, Float pret) {
        this.cantitate_cerere = cantitate_cerere;
        this.denumire = denumire;
        this.pret= pret;
    }

    public Long getId_produs() {
        return id_produs;
    }

    public void setId_produs(Long id_produs) {
        this.id_produs = id_produs;
    }

    public Float getCantitate_cerere() {
        return cantitate_cerere;
    }

    public void setCantitate_cerere(Float cantitate_cerere) {
        this.cantitate_cerere = cantitate_cerere;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public Float getPret() {
        return pret;
    }

    public void setPret(Float pret) {
        this.pret = pret;
    }

    @OneToOne
    @JoinColumn(name = "id_disponibilitate_produs")
    private Disponibilitate_Produs disponibilitate_produs;
}
