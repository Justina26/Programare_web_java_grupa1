package proiect.domain;


import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.mapping.ToOne;

import javax.persistence.*;
import java.sql.Date;
import java.util.Set;

@Entity
@Table(name = "Comanda")
public class Comanda {

    @Id
    @Column(name="id_comanda")
    private Long id;

    @Column
    private String descriere;

    @Column
    private Date data_plasarii;

    public Comanda() {

    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Date getData_plasarii() {
        return data_plasarii;
    }

    public void setData_plasarii(Date dataPlasarii) {
        this.data_plasarii = data_plasarii;
    }

    public Comanda(String descriere, Date data_plasarii) {
        this.descriere = descriere;
        this.data_plasarii = data_plasarii;
    }




}
