package proiect.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Functie_Angajat")
public class Functie_Angajat {

    @Id
    @Column
    private Long id_functie_angajat;

    @Column
    private Date data_angajarii;


    public Functie_Angajat(Date data_angajarii) {
        this.data_angajarii = data_angajarii;
    }

    public Long getId_functie_angajat() {
        return id_functie_angajat;
    }

    public void setId_functie_angajat(Long id_functie_angajat) {
        this.id_functie_angajat = id_functie_angajat;
    }

    public Date getData_angajarii() {
        return data_angajarii;
    }

    public void setData_angajarii(Date data_angajarii) {
        this.data_angajarii = data_angajarii;
    }

    @OneToOne
    @JoinColumn(name = "id_functie")
    private Functie functie;
}
